import React, { useEffect } from "react";
import Target from "../components/Target";
import Timer from "../components/Timer";
import BubbleContainer from "../components/BubbleContainer";
import { useNavigate } from "react-router-dom";

function GamePage({ time, setActive, isActive, target, bubbles, score, manageScore }) {
  const navigator = useNavigate();
  useEffect(() => {
    if (time == 0) {
      navigator("/score")
    }
  }, [time]);
  return (
    <div className="container mt-4" style={{ height: "100vh" }}>
      <h1 className="display-4 fw-bold mb-0 text-center text-warning">
        🫧 Bubble Game
      </h1>
      <p className="fs-4 mb-0 text-center">
        Pop the correct bubbles and beat your high score! 🎯
      </p>
      <div className="row">
        <div className="col justify-content-end d-flex p-2">
          <div className="score-panel bg-warning py-2 px-4 rounded shadow-sm">
            <strong>Score: {score}</strong>
          </div>
        </div>
      </div>
      <div className="row ">
        <div className="col-2">
          <div className="row mb-4">
            <div className="col">
              <div className="card p-3 border-warning">
                <Target target={target} isActive={isActive} />
              </div>
            </div>
          </div>
          <div className="row  mb-4">
            <div className="col">
              <div className="card p-3 border-warning">
                <Timer time={time} setActive={setActive} isActive={isActive} />
              </div>
            </div>
          </div>
        </div>
        <div className="col-10">
          <div className="card p-3 border-warning">
            <BubbleContainer bubbles={bubbles} manageScore={manageScore} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default GamePage;
