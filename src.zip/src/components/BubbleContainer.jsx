import React from "react";

function BubbleContainer({ bubbles, manageScore }) {
  return (
    <div className="container d-flex flex-wrap gap-2" onClick={manageScore}>
      {bubbles.map((bubble, index) => {
        return (
          <div
            key={index}
            style={{
              height: "65px",
              width: "65px",
              borderRadius: "50%",
              border: "2px solid cyan",
            }}
            className="d-flex justify-content-center align-items-center fs-3 fw-bold shadow-sm bubble"
          >
            {bubble}
          </div>
        );
      })}
    </div>
  );
}

export default BubbleContainer;
